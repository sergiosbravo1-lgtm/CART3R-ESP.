plugins { id("com.android.application") }

android {
    namespace = "com.carter.esp"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.carter.esp"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
