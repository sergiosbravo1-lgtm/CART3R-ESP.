# CART3R ESP — Android project

This is an offline Android visualizer with fictional sample targets. It does **not** connect to Blood Strike, inspect game memory, draw over another app, or provide live player tracking.

## Build an APK
1. Install Android Studio (current stable) and its Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

Requirements: JDK 17 and Android Gradle Plugin 8.7.3. No third-party libraries are used.
